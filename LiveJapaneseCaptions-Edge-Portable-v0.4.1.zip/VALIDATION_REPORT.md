Live Japanese Captions Edge Stable v0.4.0 | Validation 2026-10-20
PASS: Source JavaScript syntax check.
PASS: Model inference Javascript bundled (esbuild) and ONNX WASM artifacts copied locally.
PASS: Whisper model metadata endpoint responds with HTTP 200 from main PC.
PASS: Source unit tests: 5/5 (Linux sandbox, audio segmentation, privacy/static).
NOT YET CONFIRMED: Edge browser extension action/capture/render in actual YouTube Live.
NOT YET CONFIRMED: Real whisper WASM or WebGPU inference inside Edge; no measured latency.
Model weight download is required on first use. Translator API pair availability and model download must be checked in Edge options.
